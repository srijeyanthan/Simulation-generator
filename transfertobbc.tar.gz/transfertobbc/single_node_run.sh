#!/bin/bash
threshold=95
trycount=0
#heartbeat interval 3 means 3s
hbinterval=3
hadoopbasedir="/home/sri/hop_distro"
numberofnm=0
##starting node is 500 and then increase by 500

calculateHBVariation()
{
        startTime=$(grep "HOP::HB  Node" /home/sri/tracefiles/$numberofnm/yarn_$trycount.log |head -1 |awk '{print $2}')
        endTime=$(grep "HOP::HB  Node"   /home/sri/tracefiles/$numberofnm/yarn_$trycount.log |tail -1 |awk '{print $2}')
        numberofnm=$(grep "Simulation:"  /home/sri/tracefiles/$numberofnm/yarn_$trycount.log  | awk '{print $11}')
        totalhb=$(grep "Simulation:"     /home/sri/tracefiles/$numberofnm/yarn_$trycount.log  | awk '{print $13}')

            set -- "$startTime" 
            IFS=":"; declare -a ast=($*)

            set -- "$endTime"
            IFS=":"; declare -a ant=($*)

             endhour=${ant[0]}
             endmin=${ant[1]}
             endsec=${ant[2]}
             endhourinsec=$(expr $endhour \* 3600)
             endmininsec=$(expr $endmin \* 60)
             endtime=$(expr $endhourinsec + $endmininsec + $endsec)

             starthour=${ast[0]}
             startmin=${ast[1]}
             startsec=${ast[2]}
             starthourinsec=$(expr $starthour \* 3600)
             startmininsec=$(expr $startmin \* 60)
             starttime=$(expr $starthourinsec + $startmininsec + $startsec)

             timeduration=$(expr $endtime - $starttime)


             nodemanagerperhb=$(awk "BEGIN {print $timeduration/$hbinterval}")
             idealnumberofhb=$(expr $numberofnm*$nodemanagerperhb | bc)
             variationindecimal=$(awk "BEGIN {print $totalhb/$idealnumberofhb}")
             variation=$(expr $variationindecimal*100 | bc)
             echo "var - $variation  time duration - $timeduration number of node manager - $numberofnm" >> variation.log
             grep "Simulation:" $hadoopbasedir/hadoop-2.4.0/logs/yarn.log  >> experimentoutput.log

}



for i in `seq 500 500 500`; 
    do
     ## we are killing running rm whenever we start the new fresh experiments
   
     ssh sri@cloud6.sics.se "/home/sri/killSLSRunner.sh"
     sleep 5
 
      echo "[Simulation] going to simulate $i number of node managers"
       echo "================= Preparing the trace for node mangers - $i ======================"
           rm sls-backup/output/*   
           ssh sri@cloud6.sics.se "rm /home/sri/sls-backup/output/*"
           ssh sri@cloud6.sics.se "cp /home/sri/tracefiles/$i/sls-*.json /home/sri/sls-backup/output"


           cp /home/sri/tracefiles/$i/sls-jobs.json  sls-backup/output
           cp /home/sri/tracefiles/$i/sls-nodes.json sls-backup/output
           ## start the remote resource manager         
           ssh sri@cloud6.sics.se "/home/sri/starthadoop.sh" &
           sleep 15
        echo "================         done            ========================================= "
         while true;
          do
              ./initsimulator.sh simulator 
              ##### lets put the results in experimentloog
             logfilename="yarn_"
             logfilename+="$trycount.log"
             cp $hadoopbasedir/hadoop-2.4.0/logs/yarn.log /home/sri/tracefiles/$i/$logfilename
             
             ## download the log file from remote for calculation
             ## first check process is finished
            numberofnm=$i
            calculateHBVariation
            break
            ## echo "==============>>  Variation of the heat beats : $variation"
	     ## if (( $(bc <<< "$variation > $threshold") == 1 )); then
 	##	 echo "!!!!!!!  We reached the expected variation. so break the loop of this round >> number of node managers >> : $i"
          ##       echo "var - $variation  time duration - $timeduration number of node manager - $numberofnm" >> variation.log                 
            ##     grep "Simulation:" $hadoopbasedir/hadoop-2.4.0/logs/yarn.log  >> experimentoutput.log 
	    ## 	 break;
            ##  else
              ##   trycount=$((trycount+1))
	     ## fi
            ## if (( $trycount > 3)); then
              ##  echo "[Simulation] Number of tries is reached .. exit the experiment !!!!"
               ## exit -1
            ## fi
              
          done
done

