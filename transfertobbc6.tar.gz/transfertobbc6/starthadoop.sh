#!/bin/bash
hadoopbasedir="/home/sri/hop_distro"


###cleaning the output directory 
rm -rf $hadoopbasedir/hadoop-2.4.0/share/hadoop/tools/sls/output/
#### cleaning the existing yarn-site.xml to replace exisinting one
rm $hadoopbasedir/hadoop-2.4.0/etc/hadoop/yarn-site.xml

### lets delete all the previous yarn.log
rm $hadoopbasedir/hadoop-2.4.0/logs/yarn.*


cp       sls-backup/sls-runner.xml                      $hadoopbasedir/hadoop-2.4.0/etc/hadoop/sls-runner.xml
cp  -rf  sls-backup/output                              $hadoopbasedir/hadoop-2.4.0/share/hadoop/tools/sls/
cp       sls-backup/slsrun.sh                           $hadoopbasedir/hadoop-2.4.0/share/hadoop/tools/sls/bin
cp       sls-backup/hadoop-sls-2.4.0.jar  $hadoopbasedir/hadoop-2.4.0/share/hadoop/common/lib

  echo "=================  Starting the hadoop2.4.0 Resource manger ===================================="
  cp sls-backup/standalone-yarn-site.xml $hadoopbasedir/hadoop-2.4.0/etc/hadoop/yarn-site.xml
  cd $hadoopbasedir/hadoop-2.4.0/share/hadoop/tools/sls;
 ./bin/slsrun.sh --input-sls=output/sls-jobs.json --output-dir=output --nodes=output/sls-nodes.json --print-simulation
